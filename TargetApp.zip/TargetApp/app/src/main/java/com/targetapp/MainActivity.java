package com.targetapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    private RadioGroup mRadioGroup;

    private FragmentManager mFragmentManager;
    private FragmentTransaction mFragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFragmentManager = getSupportFragmentManager();
        mFragmentTransaction = mFragmentManager.beginTransaction();

        PatientFragment patientFragment = new PatientFragment();

        mFragmentTransaction.add(R.id.frameLayout, patientFragment);
        mFragmentTransaction.commit();

        mRadioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                mFragmentTransaction = mFragmentManager.beginTransaction();
                if (i == R.id.radioButtonPatient) {


                    PatientFragment patientFragment = new PatientFragment();

                    mFragmentTransaction.replace(R.id.frameLayout, patientFragment);

                } else if (i == R.id.radioButtonWorklist) {
                    WorklistFragment worklistFragment = new WorklistFragment();

                    mFragmentTransaction.replace(R.id.frameLayout, worklistFragment);
                } else if (i == R.id.radioButtonStudies) {
                    StudyFragment studyFragment = new StudyFragment();
                    mFragmentTransaction.replace(R.id.frameLayout, studyFragment);
                }

                mFragmentTransaction.commit();
            }
        });

        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        String message = "";
        if(intent != null && intent.getStringExtra("INTENT_MESSAGE") != null) {
            message = intent.getStringExtra("INTENT_MESSAGE");
            if(message.toLowerCase().contains("patient")) {
                mRadioGroup.check(R.id.radioButtonPatient);
            } else if(message.toLowerCase().contains("worklist")) {
                mRadioGroup.check(R.id.radioButtonWorklist);
            } else if(message.toLowerCase().contains("study")) {
                mRadioGroup.check(R.id.radioButtonStudies);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(mReceiver, new IntentFilter("com.targetreceiver.LOCAL"));
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mReceiver);
        super.onPause();
    }

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.e("", "Target Receiver");
            String message = "";
            if (intent != null && intent.getStringExtra("LOCAL_TARGET_MESSAGE") != null) {
                message = intent.getStringExtra("LOCAL_TARGET_MESSAGE");
                Log.e("", "Target Receiver " + message);
                if (message.toLowerCase().contains("click patient") || message.toLowerCase().contains("patient tab") || message.toLowerCase().contains("patient")) {
                    mRadioGroup.check(R.id.radioButtonPatient);
                } else if (message.toLowerCase().contains("click worklist") || message.toLowerCase().contains("click work list") || message.toLowerCase().contains("clickworklist") || message.toLowerCase().contains("worklist")) {
                    mRadioGroup.check(R.id.radioButtonWorklist);
                } else if (message.toLowerCase().contains("click study") || message.toLowerCase().contains("study tab") || message.toLowerCase().contains("study")) {
                    mRadioGroup.check(R.id.radioButtonStudies);
                }
            }
        }
    };
}
