package com.targetapp;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Jeorge Aromal on 11/11/2016.
 */

public class TargetReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.e("", "Target Receiver");
        if (intent.getAction().equals("com.targetreceiver.GLOBAL")) {
            String message = "";
            if (intent != null && intent.getStringExtra("TARGET_MESSAGE") != null) {
                message = intent.getStringExtra("TARGET_MESSAGE");
            }

            if (launchAppCheck(message)) {

                Intent targetIntent = new Intent(context.getApplicationContext(), MainActivity.class);
                targetIntent.putExtra("INTENT_MESSAGE",message);
                targetIntent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                targetIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                targetIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                context.startActivity(targetIntent);
            }

            else {
                Intent localIntent = new Intent();
                localIntent.setAction("com.targetreceiver.LOCAL");
                localIntent.putExtra("LOCAL_TARGET_MESSAGE", message);
                LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent);
            }
        }
    }

    private boolean launchAppCheck(String message) {

        if (message.toLowerCase().contains("launch patient") || message.toLowerCase().contains("launch study") || message.toLowerCase().contains("launch worklist") || message.toLowerCase().contains("start patient") || message.toLowerCase().contains("start patient app") || message.toLowerCase().contains("start patient application")) {
            return true;
        }
        return false;
    }
}
