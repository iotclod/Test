package com.mediatorapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Jeorge Aromal on 11/10/2016.
 */

public class MediatorReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String message = "";
        if (intent != null && intent.getStringExtra("SERVICE_MESSAGE") != null) {
            message = intent.getStringExtra("SERVICE_MESSAGE");
        }

        Intent localIntent = new Intent();
        localIntent.setAction("com.mediatorapp.receiver.LOCAL");
        localIntent.putExtra("MESSAGE", message);
        LocalBroadcastManager localBroadcastManager = LocalBroadcastManager.getInstance(context);
        localBroadcastManager.sendBroadcast(localIntent);

        Intent targetIntent = new Intent();
        targetIntent.setAction("com.targetreceiver.GLOBAL");
        targetIntent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        targetIntent.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        targetIntent.putExtra("TARGET_MESSAGE",message);
        context.sendBroadcast(targetIntent);
    }
}
